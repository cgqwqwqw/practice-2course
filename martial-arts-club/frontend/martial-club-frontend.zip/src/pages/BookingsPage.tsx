import { useMyBookings, useCancelBooking } from "@/hooks/useBookings";
import { Loader } from "@/components/Loader";
import { ErrorState, EmptyState } from "@/components/ErrorState";
import { formatDateTime } from "@/utils/format";

const STATUS_BADGE: Record<string, { cls: string; label: string }> = {
  BOOKED: { cls: "badge-green", label: "Подтверждено" },
  CANCELLED: { cls: "badge-red", label: "Отменено" },
  ATTENDED: { cls: "badge-blue", label: "Посещено" },
  NO_SHOW: { cls: "badge-amber", label: "Не явился" },
};

export function BookingsPage() {
  const bookings = useMyBookings();
  const cancel = useCancelBooking();

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-[26px]">Мои записи</h1>
        <p className="mt-1 text-[13px] text-ink/50">Забронированные тренировки и их статус</p>
      </div>

      {bookings.isLoading && <Loader />}
      {bookings.isError && <ErrorState message={bookings.error.message} onRetry={() => bookings.refetch()} />}
      {bookings.isSuccess && bookings.data.length === 0 && (
        <EmptyState message="Записей пока нет — выберите тренировку в расписании." />
      )}

      {bookings.isSuccess && bookings.data.length > 0 && (
        <div className="panel overflow-x-auto p-0">
          <table className="w-full min-w-[640px]">
            <thead>
              <tr>
                <th>Тренировка</th><th>Начало</th><th>Статус</th><th></th>
              </tr>
            </thead>
            <tbody>
              {bookings.data.map((b) => {
                const meta = STATUS_BADGE[b.status] ?? { cls: "badge-gray", label: b.status };
                const canCancel = b.status === "BOOKED" && new Date(b.sessionStartsAt) > new Date();
                return (
                  <tr key={b.id}>
                    <td className="font-medium">{b.sessionTitle}</td>
                    <td className="font-mono text-xs text-ink/60">{formatDateTime(b.sessionStartsAt)}</td>
                    <td><span className={`badge ${meta.cls}`}>{meta.label}</span></td>
                    <td className="text-right">
                      {canCancel && (
                        <button
                          className="text-[12.5px] font-semibold text-vermilion hover:underline"
                          disabled={cancel.isPending}
                          onClick={() => cancel.mutate(b.id)}
                        >
                          Отменить запись
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
